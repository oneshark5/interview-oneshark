/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
import React from 'react'
import Film from '../views/Film';
import Center from '../views/Center';
import Cinema from '../views/Cinema';
import {Route,Routes} from 'react-router-dom'
import Redirect from '../components/Redirect';
import NotFound from '../views/NotFound';

export default function MRouter() {
    return (
        <Routes>
            {/* <Route path="/" element={<Film />} /> */}
            {/* <Route index element={<Film />} /> */}
            <Route path="/films" element={<Film />} />
            <Route path="/cinemas" element={<Cinema />} />
            <Route path="/center" element={<Center />} />

            {/* <Route path="*" element={<Navigate to="/films"/>}/>  */}
            <Route path="/" element={<Redirect to="/films"/>}/> 
            <Route path="*" element={<NotFound/>}/> 
        </Routes>
    )
}
